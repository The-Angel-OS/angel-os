export interface GuardianAngel {
  id: string
  name: string
  personality: string
  isActive: boolean
  status: "active" | "idle" | "offline"
}

export interface Member {
  id: string
  name: string
  avatar?: string
  role: "Owner" | "Admin" | "Staff" | "Customer"
  status: "online" | "away" | "busy" | "offline"
  hasGuardianAngel: boolean
}

export interface Channel {
  id: string
  name: string
  type: "text" | "voice" | "video"
  unreadCount?: number
  isActive?: boolean
  hasVideo?: boolean
}

export interface BusinessMessage {
  id: string
  user: Member
  content: string
  timestamp: string
  type: "text" | "payment" | "signature" | "inventory" | "guardian"
  businessContext?: {
    orderId?: string
    amount?: number
    status?: string
    attachments?: string[]
  }
}
