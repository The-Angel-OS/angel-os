"use client"

import { Bot, Zap } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface GuardianAngelBadgeProps {
  isActive: boolean
  className?: string
}

export function GuardianAngelBadge({ isActive, className }: GuardianAngelBadgeProps) {
  return (
    <Badge
      variant={isActive ? "default" : "secondary"}
      className={cn(
        "flex items-center space-x-1 text-xs",
        isActive ? "bg-green-500 hover:bg-green-600" : "bg-gray-600",
        className,
      )}
    >
      <div className={cn("w-2 h-2 rounded-full", isActive ? "bg-green-300" : "bg-gray-400")} />
      <Bot className="w-3 h-3" />
      <span>{isActive ? "Guardian Active" : "Guardian Idle"}</span>
      {isActive && <Zap className="w-3 h-3" />}
    </Badge>
  )
}
