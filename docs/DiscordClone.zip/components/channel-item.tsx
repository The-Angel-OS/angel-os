"use client"

import { useState } from "react"
import { Hash, Volume2, Video, Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ChannelItemProps {
  type: "text" | "voice" | "video"
  name: string
  isActive?: boolean
  onClick?: () => void
  onEdit?: () => void
  onDelete?: () => void
  className?: string
}

const iconMap = {
  text: Hash,
  voice: Volume2,
  video: Video,
}

export function ChannelItem({ type, name, isActive, onClick, onEdit, onDelete, className }: ChannelItemProps) {
  const [isHovered, setIsHovered] = useState(false)
  const Icon = iconMap[type]

  return (
    <div
      className={cn(
        "group flex items-center justify-between px-2 py-1 rounded cursor-pointer transition-colors",
        isActive ? "bg-[#393c43] text-white" : "text-gray-300 hover:bg-[#393c43] hover:text-white",
        className,
      )}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-center space-x-2 flex-1 min-w-0">
        <Icon className="w-4 h-4 text-gray-400 flex-shrink-0" />
        <span className="text-sm truncate">{name}</span>
      </div>

      {/* Hover Actions */}
      {(isHovered || isActive) && (onEdit || onDelete) && (
        <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
          {onEdit && (
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation()
                onEdit()
              }}
              className="w-6 h-6 p-0 hover:bg-[#4f545c]"
            >
              <Edit className="w-3 h-3 text-gray-400 hover:text-white" />
            </Button>
          )}
          {onDelete && (
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => {
                e.stopPropagation()
                onDelete()
              }}
              className="w-6 h-6 p-0 hover:bg-red-600"
            >
              <Trash2 className="w-3 h-3 text-gray-400 hover:text-white" />
            </Button>
          )}
        </div>
      )}
    </div>
  )
}
