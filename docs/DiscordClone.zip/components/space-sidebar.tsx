"use client"

import { useState } from "react"
import {
  Search,
  Plus,
  Settings,
  Hash,
  Volume2,
  Video,
  Mic,
  Headphones,
  Settings2,
  ChevronDown,
  ChevronRight,
  ChevronLeft,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import { SpaceDropdown } from "./space-dropdown"
import { ChannelItem } from "./channel-item"

interface SpaceSidebarProps {
  isCollapsed: boolean
  onToggle: () => void
  className?: string
}

export function SpaceSidebar({ isCollapsed, onToggle, className }: SpaceSidebarProps) {
  const [expandedSections, setExpandedSections] = useState({
    textChannels: true,
    voiceChannels: true,
    videoChannels: true,
    members: true,
  })

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }))
  }

  if (isCollapsed) {
    return (
      <div className={cn("w-16 bg-[#2f3136] flex flex-col items-center py-3", className)}>
        {/* Collapsed Space Icon */}
        <div className="mb-4">
          <Avatar className="w-12 h-12 cursor-pointer hover:rounded-2xl transition-all duration-200" onClick={onToggle}>
            <AvatarImage src="/placeholder.svg?height=48&width=48" />
            <AvatarFallback className="bg-[#5865f2] text-white font-bold hover:bg-[#4752c4] transition-colors">
              KD
            </AvatarFallback>
          </Avatar>
        </div>

        {/* Collapsed Channel Icons */}
        <div className="space-y-2">
          <Button
            variant="ghost"
            size="sm"
            className="w-12 h-12 p-0 rounded-full hover:bg-[#393c43] hover:rounded-2xl transition-all duration-200"
          >
            <Hash className="w-5 h-5 text-gray-400" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="w-12 h-12 p-0 rounded-full hover:bg-[#393c43] hover:rounded-2xl transition-all duration-200"
          >
            <Volume2 className="w-5 h-5 text-gray-400" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="w-12 h-12 p-0 rounded-full hover:bg-[#393c43] hover:rounded-2xl transition-all duration-200"
          >
            <Video className="w-5 h-5 text-gray-400" />
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className={cn("w-60 bg-[#2f3136] flex flex-col", className)}>
      {/* Space Header with Collapse Button */}
      <div className="border-b border-[#202225] shadow-sm relative">
        <SpaceDropdown
          spaceName="Code with KenDev"
          spaceInitials="KD"
          onSpaceSettings={() => console.log("Space Settings")}
          onManageMembers={() => console.log("Manage Members")}
          onSendInvitation={() => console.log("Send Invitation")}
          onCreateChannel={() => console.log("Create Channel")}
          onDeleteSpace={() => console.log("Delete Space")}
        />
        {/* Collapse Button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onToggle}
          className="absolute right-2 top-1/2 -translate-y-1/2 w-6 h-6 p-0 hover:bg-[#393c43] transition-colors"
        >
          <ChevronLeft className="w-4 h-4 text-gray-400" />
        </Button>
      </div>

      {/* Search */}
      <div className="p-2">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search"
            className="pl-8 bg-[#202225] border-none text-gray-300 placeholder-gray-500 focus:ring-0 focus:border-none"
          />
          <span className="absolute right-2 top-2 text-xs text-gray-500">CTRL+S</span>
        </div>
      </div>

      {/* Channels */}
      <div className="flex-1 overflow-y-auto">
        {/* Text Channels */}
        <div className="px-2 py-1">
          <button
            onClick={() => toggleSection("textChannels")}
            className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
          >
            <div className="flex items-center space-x-1">
              {expandedSections.textChannels ? (
                <ChevronDown className="w-3 h-3" />
              ) : (
                <ChevronRight className="w-3 h-3" />
              )}
              <span>Text Channels</span>
            </div>
            <Plus className="w-4 h-4" />
          </button>

          {expandedSections.textChannels && (
            <div className="mt-1 space-y-0.5">
              <ChannelItem
                type="text"
                name="general"
                isActive={true}
                onClick={() => console.log("Navigate to general")}
                onEdit={() => console.log("Edit general")}
                onDelete={() => console.log("Delete general")}
              />
              <ChannelItem
                type="text"
                name="links"
                onClick={() => console.log("Navigate to links")}
                onEdit={() => console.log("Edit links")}
                onDelete={() => console.log("Delete links")}
              />
              <ChannelItem
                type="text"
                name="system"
                onClick={() => console.log("Navigate to system")}
                onEdit={() => console.log("Edit system")}
                onDelete={() => console.log("Delete system")}
              />
              <ChannelItem
                type="text"
                name="research"
                onClick={() => console.log("Navigate to research")}
                onEdit={() => console.log("Edit research")}
                onDelete={() => console.log("Delete research")}
              />
              <ChannelItem
                type="text"
                name="news"
                onClick={() => console.log("Navigate to news")}
                onEdit={() => console.log("Edit news")}
                onDelete={() => console.log("Delete news")}
              />
              <ChannelItem
                type="text"
                name="youtube"
                onClick={() => console.log("Navigate to youtube")}
                onEdit={() => console.log("Edit youtube")}
                onDelete={() => console.log("Delete youtube")}
              />
            </div>
          )}
        </div>

        {/* Voice Channels */}
        <div className="px-2 py-1 mt-4">
          <button
            onClick={() => toggleSection("voiceChannels")}
            className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
          >
            <div className="flex items-center space-x-1">
              {expandedSections.voiceChannels ? (
                <ChevronDown className="w-3 h-3" />
              ) : (
                <ChevronRight className="w-3 h-3" />
              )}
              <span>Voice Channels</span>
            </div>
            <Plus className="w-4 h-4" />
          </button>

          {expandedSections.voiceChannels && (
            <div className="mt-1 space-y-0.5">
              <ChannelItem
                type="voice"
                name="Talk Time"
                onClick={() => console.log("Join Talk Time")}
                onEdit={() => console.log("Edit Talk Time")}
                onDelete={() => console.log("Delete Talk Time")}
              />
            </div>
          )}
        </div>

        {/* Video Channels */}
        <div className="px-2 py-1 mt-4">
          <button
            onClick={() => toggleSection("videoChannels")}
            className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
          >
            <div className="flex items-center space-x-1">
              {expandedSections.videoChannels ? (
                <ChevronDown className="w-3 h-3" />
              ) : (
                <ChevronRight className="w-3 h-3" />
              )}
              <span>Video Channels</span>
            </div>
            <Plus className="w-4 h-4" />
          </button>

          {expandedSections.videoChannels && (
            <div className="mt-1 space-y-0.5">
              <ChannelItem
                type="video"
                name="Video Channel"
                onClick={() => console.log("Join Video Channel")}
                onEdit={() => console.log("Edit Video Channel")}
                onDelete={() => console.log("Delete Video Channel")}
              />
            </div>
          )}
        </div>

        {/* Members */}
        <div className="px-2 py-1 mt-4">
          <button
            onClick={() => toggleSection("members")}
            className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
          >
            <div className="flex items-center space-x-1">
              {expandedSections.members ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
              <span>Members</span>
            </div>
            <Settings className="w-4 h-4" />
          </button>

          {expandedSections.members && (
            <div className="mt-1 space-y-1">
              <div className="flex items-center space-x-2 px-2 py-1">
                <Avatar className="w-6 h-6">
                  <AvatarImage src="/placeholder.svg?height=24&width=24" />
                  <AvatarFallback className="bg-red-500 text-white text-xs">M</AvatarFallback>
                </Avatar>
                <span className="text-sm text-gray-300">Manoj Bhuva</span>
              </div>
              <div className="flex items-center space-x-2 px-2 py-1">
                <Avatar className="w-6 h-6">
                  <AvatarImage src="/placeholder.svg?height=24&width=24" />
                  <AvatarFallback className="bg-blue-500 text-white text-xs">R</AvatarFallback>
                </Avatar>
                <span className="text-sm text-gray-300">Ren</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* User Panel */}
      <div className="p-2 bg-[#292b2f] border-t border-[#202225]">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Avatar className="w-8 h-8">
              <AvatarImage src="/placeholder.svg?height=32&width=32" />
              <AvatarFallback className="bg-green-500 text-white text-xs">U</AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-white">User</span>
              <span className="text-xs text-gray-400">Online</span>
            </div>
          </div>
          <div className="flex items-center space-x-1">
            <Button variant="ghost" size="sm" className="w-8 h-8 p-0 hover:bg-[#393c43]">
              <Mic className="w-4 h-4 text-gray-400" />
            </Button>
            <Button variant="ghost" size="sm" className="w-8 h-8 p-0 hover:bg-[#393c43]">
              <Headphones className="w-4 h-4 text-gray-400" />
            </Button>
            <Button variant="ghost" size="sm" className="w-8 h-8 p-0 hover:bg-[#393c43]">
              <Settings2 className="w-4 h-4 text-gray-400" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
