"use client"

import { useState } from "react"
import { Send, CreditCard, FileText, Package, Zap, TrendingUp, Users, Target } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"

interface LeoAssistantProps {
  className?: string
}

export function LeoAssistant({ className }: LeoAssistantProps) {
  const [message, setMessage] = useState("")
  const [isListening, setIsListening] = useState(false)

  const quickActions = [
    { icon: CreditCard, label: "Process Payment", color: "bg-green-600 hover:bg-green-700" },
    { icon: FileText, label: "Send Signature", color: "bg-blue-600 hover:bg-blue-700" },
    { icon: Package, label: "Check Inventory", color: "bg-purple-600 hover:bg-purple-700" },
  ]

  const businessInsights = [
    { title: "Revenue Today", value: "$12,450", change: "+15%", icon: TrendingUp, color: "text-green-400" },
    { title: "Active Customers", value: "234", change: "+8", icon: Users, color: "text-blue-400" },
    { title: "Conversion Rate", value: "3.2%", change: "+0.5%", icon: Target, color: "text-purple-400" },
  ]

  return (
    <div className={cn("w-[320px] bg-[#2f3136] flex flex-col border-l border-[#202225]", className)}>
      {/* Leo Header */}
      <div className="p-4 border-b border-[#202225]">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <Avatar className="w-10 h-10">
              <AvatarImage src="/placeholder.svg?height=40&width=40" />
              <AvatarFallback className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">LEO</AvatarFallback>
            </Avatar>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
              <Zap className="w-2 h-2 text-white" />
            </div>
          </div>
          <div>
            <h3 className="font-bold text-white">Leo Assistant</h3>
            <p className="text-xs text-green-400">AI Guardian Active</p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="p-4 border-b border-[#202225]">
        <h4 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wide">Quick Actions</h4>
        <div className="space-y-2">
          {quickActions.map((action, index) => (
            <Button
              key={index}
              variant="ghost"
              className={cn("w-full justify-start text-white", action.color)}
              size="sm"
            >
              <action.icon className="w-4 h-4 mr-2" />
              {action.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Business Intelligence */}
      <div className="p-4 border-b border-[#202225]">
        <h4 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wide">Business Intelligence</h4>
        <div className="space-y-3">
          {businessInsights.map((insight, index) => (
            <Card key={index} className="bg-[#36393f] border-[#202225]">
              <CardContent className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <insight.icon className={cn("w-4 h-4", insight.color)} />
                    <span className="text-xs text-gray-400">{insight.title}</span>
                  </div>
                  <Badge variant="outline" className={cn("text-xs", insight.color.replace("text-", "border-"))}>
                    {insight.change}
                  </Badge>
                </div>
                <p className="text-lg font-bold text-white mt-1">{insight.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Guardian Angel Personality */}
      <div className="p-4 border-b border-[#202225]">
        <h4 className="text-sm font-semibold text-gray-400 mb-3 uppercase tracking-wide">Guardian Personality</h4>
        <div className="space-y-2">
          <div className="flex items-center justify-between p-2 bg-[#36393f] rounded">
            <span className="text-sm text-white">Business Advisor</span>
            <Badge className="bg-green-600">Active</Badge>
          </div>
          <p className="text-xs text-gray-400">Focused on revenue optimization and customer conversion strategies.</p>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="flex-1 flex flex-col">
        <div className="flex-1 p-4 overflow-y-auto">
          <div className="space-y-3">
            <div className="flex space-x-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback className="bg-gradient-to-r from-purple-500 to-blue-500 text-white text-xs">
                  L
                </AvatarFallback>
              </Avatar>
              <div className="bg-[#36393f] rounded-lg p-2 max-w-[200px]">
                <p className="text-sm text-white">
                  I've detected 3 high-value customers in your support queue. Should I prioritize their tickets?
                </p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Avatar className="w-6 h-6">
                <AvatarFallback className="bg-gradient-to-r from-purple-500 to-blue-500 text-white text-xs">
                  L
                </AvatarFallback>
              </Avatar>
              <div className="bg-[#36393f] rounded-lg p-2 max-w-[200px]">
                <p className="text-sm text-white">
                  Your inventory for "Premium Widget" is running low. I can auto-reorder based on sales velocity.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Input */}
        <div className="p-4 border-t border-[#202225]">
          <div className="flex items-center space-x-2">
            <Input
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Ask Leo anything..."
              className="flex-1 bg-[#40444b] border-none text-white placeholder-gray-400 focus:ring-0 focus:border-none"
            />
            <Button size="sm" className="bg-[#5865f2] hover:bg-[#4752c4]">
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex items-center justify-between mt-2">
            <Badge variant="outline" className="text-xs text-gray-400 border-gray-600">
              Intent: Business Query
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              className={cn("text-xs", isListening ? "text-red-400" : "text-gray-400")}
              onClick={() => setIsListening(!isListening)}
            >
              🎤 {isListening ? "Listening..." : "Voice"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
