"use client"

import { useState, useEffect } from "react"
import { BusinessSidebar } from "./components/business-sidebar"
import { BusinessChatArea } from "./components/business-chat-area"
import { LeoAssistant } from "./components/leo-assistant"
import { useIsMobile } from "./hooks/use-mobile"
import { cn } from "@/lib/utils"

export default function SpacesCommerceInterface() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [isLeoVisible, setIsLeoVisible] = useState(true)
  const isMobile = useIsMobile()

  useEffect(() => {
    if (isMobile) {
      setIsSidebarCollapsed(true)
      setIsLeoVisible(false)
    } else {
      setIsLeoVisible(true)
    }
  }, [isMobile])

  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed)
  }

  return (
    <div className="flex h-screen bg-[#1e2124] text-white overflow-hidden">
      {/* Business Sidebar */}
      <BusinessSidebar
        isCollapsed={isSidebarCollapsed}
        onToggle={toggleSidebar}
        className={cn("transition-all duration-300 ease-in-out", isMobile && isSidebarCollapsed && "hidden")}
      />

      {/* Mobile Overlay */}
      {isMobile && !isSidebarCollapsed && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden" onClick={toggleSidebar} />
      )}

      {/* Main Chat Area */}
      <BusinessChatArea
        isSidebarCollapsed={isSidebarCollapsed}
        onToggleSidebar={toggleSidebar}
        className="flex-1 min-w-0"
      />

      {/* Leo Assistant Panel */}
      {isLeoVisible && !isMobile && <LeoAssistant className="transition-all duration-300 ease-in-out" />}
    </div>
  )
}
