"use client"

import { useState, useEffect, useRef } from "react"
import { Hash, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ChatInput } from "@/components/ui/chat-input"
import { ChatMessage } from "@/components/ui/chat-message"
import { InfiniteScroll } from "@/components/ui/infinite-scroll"
import { cn } from "@/lib/utils"
import { ConnectionStatus } from "./connection-status"

interface Message {
  id: string
  user: {
    name: string
    avatar: string
    initials: string
    color: string
  }
  content: string
  timestamp: string
  isExpandable?: boolean
  expandedContent?: string
}

interface ChatAreaProps {
  isSidebarCollapsed: boolean
  onToggleSidebar: () => void
  className?: string
}

const initialMessages: Message[] = [
  {
    id: "1",
    user: {
      name: "Kenneth Courtney",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "KC",
      color: "bg-blue-500",
    },
    content: "Let's try Tavily for BPM Top 20 or 15 or whatever their daily show is Top 15 pretty sure.",
    timestamp: "14 Jun 2025, 18:56",
  },
  {
    id: "2",
    user: {
      name: "System User",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SU",
      color: "bg-gray-600",
    },
    content:
      "🎯 Initiating Tavily Search for BPM's Top Tracks\n\nGiven the current limitations with direct data retrieval, I'll outline a strategic approach to leverage Tavily for identifying BPM's top tracks, focusing on their daily show, which you've indicated is likely the Top 15.\n\nStrategic Approach to Use Tavily for BPM's Top Tracks:\n\n1",
    timestamp: "14 Jun 2025, 19:02",
    isExpandable: true,
    expandedContent: "Additional content would be loaded here...",
  },
]

export function ChatArea({ isSidebarCollapsed, onToggleSidebar, className }: ChatAreaProps) {
  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [isLoading, setIsLoading] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const loadMoreMessages = async () => {
    if (isLoading || !hasMore) return

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const newMessages: Message[] = [
      {
        id: `${messages.length + 1}`,
        user: {
          name: "Previous User",
          avatar: "/placeholder.svg?height=40&width=40",
          initials: "PU",
          color: "bg-purple-500",
        },
        content: "This is an older message loaded via infinite scroll.",
        timestamp: "14 Jun 2025, 17:30",
      },
    ]

    setMessages((prev) => [...newMessages, ...prev])
    setIsLoading(false)

    // Simulate reaching the end after a few loads
    if (messages.length > 10) {
      setHasMore(false)
    }
  }

  const handleSendMessage = (content: string) => {
    const newMessage: Message = {
      id: `${Date.now()}`,
      user: {
        name: "You",
        avatar: "/placeholder.svg?height=40&width=40",
        initials: "Y",
        color: "bg-green-500",
      },
      content,
      timestamp: new Date().toLocaleString(),
    }

    setMessages((prev) => [...prev, newMessage])
  }

  return (
    <div className={cn("flex-1 flex flex-col", className)}>
      {/* Channel Header */}
      <div className="h-12 bg-[#36393f] border-b border-[#202225] flex items-center justify-between px-4">
        <div className="flex items-center space-x-2">
          {/* Mobile Space Icon - only show when sidebar is collapsed on mobile */}
          <div className="md:hidden">
            {isSidebarCollapsed && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onToggleSidebar}
                className="w-8 h-8 p-0 hover:bg-[#393c43] mr-2"
              >
                <Avatar className="w-6 h-6">
                  <AvatarImage src="/placeholder.svg?height=24&width=24" />
                  <AvatarFallback className="bg-[#5865f2] text-white text-xs">KD</AvatarFallback>
                </Avatar>
              </Button>
            )}
          </div>

          {/* Desktop Menu Button */}
          <div className="hidden md:block">
            {isSidebarCollapsed && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onToggleSidebar}
                className="w-8 h-8 p-0 hover:bg-[#393c43] mr-2"
              >
                <Menu className="w-4 h-4 text-gray-400" />
              </Button>
            )}
          </div>

          <Hash className="w-5 h-5 text-gray-400" />
          <span className="font-semibold text-white">general</span>
        </div>
        <ConnectionStatus isConnected={false} onReconnect={() => console.log("Reconnecting...")} />
      </div>

      {/* Messages with Infinite Scroll */}
      <div className="flex-1 overflow-hidden">
        <InfiniteScroll
          hasMore={hasMore}
          isLoading={isLoading}
          next={loadMoreMessages}
          threshold={100}
          className="h-full"
        >
          <div className="p-4 space-y-4 min-h-full flex flex-col justify-end">
            {messages.map((message) => (
              <ChatMessage
                key={message.id}
                user={message.user}
                content={message.content}
                timestamp={message.timestamp}
                isExpandable={message.isExpandable}
                onExpand={() => {
                  // Handle expand functionality
                  console.log("Expand message:", message.id)
                }}
              />
            ))}
            <div ref={messagesEndRef} />
          </div>
        </InfiniteScroll>
      </div>

      {/* Chat Input */}
      <div className="p-4 bg-[#36393f]">
        <ChatInput
          placeholder="Message #general (Shift+Enter for new line, paste URLs for research)"
          onSubmit={handleSendMessage}
        />
      </div>
    </div>
  )
}
