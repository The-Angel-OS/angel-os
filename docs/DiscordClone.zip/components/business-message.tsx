"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Bot, CreditCard, FileText, Package, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"
import type { BusinessMessage } from "../types/business"

interface BusinessMessageProps {
  message: BusinessMessage
  className?: string
}

export function BusinessMessageCard({ message, className }: BusinessMessageProps) {
  const renderBusinessCard = () => {
    if (!message.businessContext) return null

    switch (message.type) {
      case "payment":
        return (
          <Card className="mt-2 bg-[#2f3136] border-[#202225]">
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <CreditCard className="w-4 h-4 text-green-400" />
                  <span className="text-sm text-white font-medium">Payment Request</span>
                </div>
                <Badge variant="outline" className="text-green-400 border-green-400">
                  ${message.businessContext.amount}
                </Badge>
              </div>
              <p className="text-xs text-gray-400 mt-1">Order #{message.businessContext.orderId}</p>
              <div className="flex space-x-2 mt-2">
                <Button size="sm" className="bg-green-600 hover:bg-green-700">
                  <CheckCircle className="w-3 h-3 mr-1" />
                  Approve
                </Button>
                <Button size="sm" variant="outline">
                  Review
                </Button>
              </div>
            </CardContent>
          </Card>
        )

      case "signature":
        return (
          <Card className="mt-2 bg-[#2f3136] border-[#202225]">
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <FileText className="w-4 h-4 text-blue-400" />
                  <span className="text-sm text-white font-medium">Signature Required</span>
                </div>
                <Badge variant="outline" className="text-yellow-400 border-yellow-400">
                  <Clock className="w-3 h-3 mr-1" />
                  Pending
                </Badge>
              </div>
              <p className="text-xs text-gray-400 mt-1">Contract Agreement - {message.businessContext.orderId}</p>
              <Button size="sm" className="mt-2 bg-blue-600 hover:bg-blue-700">
                <FileText className="w-3 h-3 mr-1" />
                Sign Document
              </Button>
            </CardContent>
          </Card>
        )

      case "inventory":
        return (
          <Card className="mt-2 bg-[#2f3136] border-[#202225]">
            <CardContent className="p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Package className="w-4 h-4 text-purple-400" />
                  <span className="text-sm text-white font-medium">Inventory Alert</span>
                </div>
                <Badge variant="outline" className="text-red-400 border-red-400">
                  <AlertCircle className="w-3 h-3 mr-1" />
                  Low Stock
                </Badge>
              </div>
              <p className="text-xs text-gray-400 mt-1">Product analysis complete</p>
              {message.businessContext.attachments && (
                <div className="flex space-x-1 mt-2">
                  {message.businessContext.attachments.map((_, index) => (
                    <div key={index} className="w-12 h-12 bg-[#36393f] rounded border border-[#202225]" />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )

      default:
        return null
    }
  }

  return (
    <div className={cn("flex space-x-3", className)}>
      <div className="relative">
        <Avatar className="w-10 h-10 mt-1">
          <AvatarImage src={message.user.avatar || "/placeholder.svg?height=40&width=40"} />
          <AvatarFallback className="bg-blue-500 text-white">
            {message.user.name
              .split(" ")
              .map((n) => n[0])
              .join("")}
          </AvatarFallback>
        </Avatar>
        {message.type === "guardian" && (
          <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full flex items-center justify-center">
            <Bot className="w-3 h-3 text-white" />
          </div>
        )}
      </div>
      <div className="flex-1">
        <div className="flex items-center space-x-2 mb-1">
          <span className="font-semibold text-white">{message.user.name}</span>
          <Badge variant="outline" className="text-xs text-gray-400 border-gray-600">
            {message.user.role}
          </Badge>
          {message.user.hasGuardianAngel && <Bot className="w-3 h-3 text-green-400" />}
          <span className="text-xs text-gray-400">{message.timestamp}</span>
        </div>
        <div className="text-gray-300 whitespace-pre-wrap">{message.content}</div>
        {renderBusinessCard()}
      </div>
    </div>
  )
}
