"use client"

import { useEffect, useRef, type ReactNode } from "react"
import { cn } from "@/lib/utils"

interface InfiniteScrollProps {
  children: ReactNode
  hasMore: boolean
  isLoading: boolean
  next: () => void
  threshold?: number
  className?: string
}

export function InfiniteScroll({ children, hasMore, isLoading, next, threshold = 1, className }: InfiniteScrollProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const scrollElement = scrollRef.current
    if (!scrollElement) return

    const handleScroll = () => {
      if (isLoading || !hasMore) return

      const { scrollTop } = scrollElement

      // Check if we're near the top (for loading older messages)
      if (scrollTop <= threshold) {
        next()
      }
    }

    scrollElement.addEventListener("scroll", handleScroll)
    return () => scrollElement.removeEventListener("scroll", handleScroll)
  }, [hasMore, isLoading, next, threshold])

  return (
    <div ref={scrollRef} className={cn("overflow-y-auto", className)}>
      {isLoading && (
        <div className="flex justify-center p-4">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white"></div>
        </div>
      )}
      {children}
    </div>
  )
}
