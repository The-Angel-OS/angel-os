"use client"

import SpacesCommerceInterface from "../spaces-commerce-interface"

export default function Page() {
  return <SpacesCommerceInterface />
}
