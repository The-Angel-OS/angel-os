"use client"

import { useState } from "react"
import {
  Search,
  Plus,
  Settings,
  Hash,
  BarChart3,
  Target,
  Users,
  Bot,
  Newspaper,
  CreditCard,
  FileText,
  Package,
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  VideoIcon,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { GuardianAngelBadge } from "./guardian-angel-badge"
import type { Channel, Member } from "../types/business"

interface BusinessSidebarProps {
  isCollapsed: boolean
  onToggle: () => void
  className?: string
}

const channels: Channel[] = [
  { id: "1", name: "general", type: "text", isActive: true, hasVideo: true },
  { id: "2", name: "orders", type: "text", unreadCount: 3, hasVideo: true },
  { id: "3", name: "customer-support", type: "text", unreadCount: 12, hasVideo: true },
  { id: "4", name: "inventory", type: "text", hasVideo: true },
  { id: "5", name: "marketing", type: "text", unreadCount: 1, hasVideo: true },
]

const members: Member[] = [
  { id: "1", name: "Sarah Chen", role: "Owner", status: "online", hasGuardianAngel: true },
  { id: "2", name: "Mike Rodriguez", role: "Admin", status: "online", hasGuardianAngel: true },
  { id: "3", name: "Emma Wilson", role: "Staff", status: "away", hasGuardianAngel: false },
  { id: "4", name: "David Kim", role: "Customer", status: "online", hasGuardianAngel: false },
]

export function BusinessSidebar({ isCollapsed, onToggle, className }: BusinessSidebarProps) {
  const [expandedSections, setExpandedSections] = useState({
    channels: true,
    members: true,
    admin: false,
  })

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }))
  }

  if (isCollapsed) {
    return (
      <div className={cn("w-16 bg-[#2f3136] flex flex-col items-center py-3", className)}>
        <div className="mb-4">
          <Avatar className="w-12 h-12 cursor-pointer hover:rounded-2xl transition-all duration-200" onClick={onToggle}>
            <AvatarImage src="/placeholder.svg?height=48&width=48" />
            <AvatarFallback className="bg-[#5865f2] text-white font-bold">SC</AvatarFallback>
          </Avatar>
        </div>
        <div className="space-y-2">
          <Button
            variant="ghost"
            size="sm"
            className="w-12 h-12 p-0 rounded-full hover:bg-[#393c43] hover:rounded-2xl transition-all duration-200"
          >
            <Hash className="w-5 h-5 text-gray-400" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="w-12 h-12 p-0 rounded-full hover:bg-[#393c43] hover:rounded-2xl transition-all duration-200"
          >
            <Users className="w-5 h-5 text-gray-400" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="w-12 h-12 p-0 rounded-full hover:bg-[#393c43] hover:rounded-2xl transition-all duration-200"
          >
            <Settings className="w-5 h-5 text-gray-400" />
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className={cn("w-[280px] bg-[#2f3136] flex flex-col", className)}>
      {/* Header Section */}
      <div className="p-4 border-b border-[#202225] relative">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Avatar className="w-8 h-8">
              <AvatarImage src="/placeholder.svg?height=32&width=32" />
              <AvatarFallback className="bg-[#5865f2] text-white text-xs">SC</AvatarFallback>
            </Avatar>
            <div>
              <h2 className="font-bold text-white text-sm">Spaces Commerce</h2>
              <p className="text-xs text-gray-400">Premium Tenant</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onToggle} className="w-6 h-6 p-0 hover:bg-[#393c43]">
            <ChevronLeft className="w-4 h-4 text-gray-400" />
          </Button>
        </div>
        <GuardianAngelBadge isActive={true} />
      </div>

      {/* Search */}
      <div className="p-3">
        <div className="relative">
          <Search className="absolute left-2 top-2.5 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search channels..."
            className="pl-8 bg-[#202225] border-none text-gray-300 placeholder-gray-500 focus:ring-0 focus:border-none"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Channels Section */}
        <div className="px-3 py-2">
          <button
            onClick={() => toggleSection("channels")}
            className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
          >
            <div className="flex items-center space-x-1">
              {expandedSections.channels ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
              <span>Channels</span>
            </div>
            <Plus className="w-4 h-4" />
          </button>

          {expandedSections.channels && (
            <div className="mt-2 space-y-1">
              {channels.map((channel) => (
                <div
                  key={channel.id}
                  className={cn(
                    "group flex items-center justify-between px-2 py-1.5 rounded cursor-pointer transition-colors",
                    channel.isActive ? "bg-[#393c43] text-white" : "text-gray-300 hover:bg-[#393c43] hover:text-white",
                  )}
                >
                  <div className="flex items-center space-x-2 flex-1">
                    <Hash className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium">{channel.name}</span>
                    {channel.unreadCount && (
                      <Badge variant="destructive" className="text-xs px-1.5 py-0.5 min-w-[18px] h-5">
                        {channel.unreadCount}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {channel.hasVideo && (
                      <Button variant="ghost" size="sm" className="w-6 h-6 p-0 hover:bg-[#4f545c]">
                        <VideoIcon className="w-3 h-3 text-gray-400 hover:text-white" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Members Section */}
        <div className="px-3 py-2">
          <button
            onClick={() => toggleSection("members")}
            className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
          >
            <div className="flex items-center space-x-1">
              {expandedSections.members ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
              <span>Members ({members.length})</span>
            </div>
          </button>

          {expandedSections.members && (
            <div className="mt-2 space-y-1">
              {members.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center space-x-2 px-2 py-1.5 hover:bg-[#393c43] rounded cursor-pointer"
                >
                  <div className="relative">
                    <Avatar className="w-7 h-7">
                      <AvatarImage src={`/placeholder.svg?height=28&width=28`} />
                      <AvatarFallback className="bg-blue-500 text-white text-xs">
                        {member.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={cn(
                        "absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#2f3136]",
                        member.status === "online"
                          ? "bg-green-500"
                          : member.status === "away"
                            ? "bg-yellow-500"
                            : member.status === "busy"
                              ? "bg-red-500"
                              : "bg-gray-500",
                      )}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-1">
                      <span className="text-sm text-gray-300 truncate">{member.name}</span>
                      {member.hasGuardianAngel && <Bot className="w-3 h-3 text-green-400" />}
                    </div>
                    <Badge variant="outline" className="text-xs text-gray-400 border-gray-600">
                      {member.role}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Admin/Control Panel Section */}
        <div className="px-3 py-2">
          <button
            onClick={() => toggleSection("admin")}
            className="flex items-center justify-between w-full p-1 text-xs font-semibold text-gray-400 hover:text-gray-300 uppercase tracking-wide"
          >
            <div className="flex items-center space-x-1">
              {expandedSections.admin ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
              <Settings className="w-3 h-3" />
              <span>Control Panel</span>
            </div>
          </button>

          {expandedSections.admin && (
            <div className="mt-2 space-y-1">
              {[
                { icon: BarChart3, label: "Analytics Dashboard", color: "text-blue-400" },
                { icon: Target, label: "Campaigns Manager", color: "text-purple-400" },
                { icon: Users, label: "Contacts & CRM", color: "text-green-400" },
                { icon: Bot, label: "Guardian Angels", color: "text-yellow-400" },
                { icon: Newspaper, label: "News Agents", color: "text-orange-400" },
                { icon: CreditCard, label: "Payment Processing", color: "text-emerald-400" },
                { icon: FileText, label: "Document Signatures", color: "text-indigo-400" },
                { icon: Package, label: "Inventory Management", color: "text-pink-400" },
                { icon: Settings, label: "Space Settings", color: "text-gray-400" },
              ].map((item, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-2 px-2 py-1.5 hover:bg-[#393c43] rounded cursor-pointer text-gray-300 hover:text-white transition-colors"
                >
                  <item.icon className={cn("w-4 h-4", item.color)} />
                  <span className="text-sm">{item.label}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* User Panel */}
      <div className="p-3 bg-[#292b2f] border-t border-[#202225]">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Avatar className="w-8 h-8">
              <AvatarImage src="/placeholder.svg?height=32&width=32" />
              <AvatarFallback className="bg-green-500 text-white text-xs">JD</AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-white">John Doe</span>
              <span className="text-xs text-gray-400">Business Owner</span>
            </div>
          </div>
          <GuardianAngelBadge isActive={true} className="text-xs" />
        </div>
      </div>
    </div>
  )
}
